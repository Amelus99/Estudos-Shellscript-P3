#!/bin/bash

echo -e "Richter: Die monster. You don't belong in this world!
\nDracula: It was not by my hand that I am once again given flesh. I was called here by humans, who wish to pay me tribute.
\nRichter: Tribute? You steal men's souls, and make them your slaves.
\nDracula: Perhaps the same could be said of all religions.
\nRichter: Your words are as empty as your soul. Mankind ill needs a savior such as you.
\nDracula: What is a man?! A miserable little pile of secrets! But enough talk; have at you!
\nSim, sou muito fã de castlevania :D"
