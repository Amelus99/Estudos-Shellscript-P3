#! /bin/bash

echo -e "-a para exibir tudo. \n-n para exibir as informações de rede. \n-d para exibir as informações de memoria e distribuição. \n-p para exibir as informações do processador. \n-u para exibir as informações dos usuarios ativos. \nexit para sair.\n"
read -p "Digite a opção( -a -n -d -p -u ou exit para sair): " op

echo -e "\n"

while [ "${op}" != "exit" ]; do

	if [[ $op == -n ]]; then
		echo -e "REDE\n"
		hostname -i
		route
		ping -c 1 8.8.8.8 | grep PING
		echo -e "\n"

	elif [[ $op == -p ]]; then
		echo -e "PROCESSADOR\n"
		lscpu | grep Nome
		lscpu | grep Arquitetura
		lscpu | grep 'CPU(s)'
		echo -e "\n"
	
	elif [[ $op == -d ]]; then
		echo -e "MEMORIA RAM\n"
		cat /proc/meminfo | grep MemAvailable
		cat /proc/meminfo | grep MemTotal
		echo -e "\nDISTRIBUIÇÃO\n"
		cat /etc/os-release | grep PRETTY
		uname -o
		uname -r
		echo -e "\nDISCOS E PARTIÇÕES\n"
		df -h
		echo -e "\n"
	
	elif [[ $op == -u ]]; then
		echo -e "USUARIOS ATIVOS\n"
		users
		echo -e "\n"
	
	elif [[ $op == -a ]]; then
		echo -e "USUARIOS ATIVOS\n"
		users
		echo -e "\nREDE\n"
		hostname -i
		route
		ping -c 1 8.8.8.8 | grep PING
		echo -e "\nPROCESSADOR\n"
		lscpu | grep Nome
		lscpu | grep Arquitetura
		lscpu | grep CPU
		echo -e "\nDISTRIBUIÇÃO\n"
		cat /etc/os-release | grep PRETTY
		uname -o
		uname -r
		echo -e "\nMEMORIA RAM\n"
		cat /proc/meminfo | grep MemAvailable
		cat /proc/meminfo | grep MemTotal
		echo -e "\nDISCOS E PARTIÇÕES"
		df -h	
		echo -e "\n"
	
	else
		echo -e "\nComando não existente.\n"
	fi

	read -p "Digite a opção( -a -n -d -p -u ou exit para sair): " op
	echo -e "\n"
done

