#! /bin/bash

[ -d "${1}" ] && echo "SIM" || echo "tem gente que é igual nuvem, as vezes eu olho e vejo um animal."
[ -d "${2}" ] && echo "SIM" || echo "tem gente que é igual nuvem, as vezes eu olho e vejo um animal."
[ -d "${3}" ] && echo "SIM" || echo "tem gente que é igual nuvem, as vezes eu olho e vejo um animal."

