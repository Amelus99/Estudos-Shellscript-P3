#! /bin/bash

ls ${1} >> ok.log 2> erro.log
ls ${2} >> ok.log 2> erro.log
ls ${3} >> ok.log 2> erro.log
